-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 06:26 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gownrentalp`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientgowns`
--

CREATE TABLE `clientgowns` (
  `gown_id` int(20) NOT NULL,
  `client_username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clientgowns`
--

INSERT INTO `clientgowns` (`gown_id`, `client_username`) VALUES
(39, 'amir'),
(41, 'amir');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_username` varchar(50) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_phone` varchar(15) NOT NULL,
  `client_email` varchar(25) NOT NULL,
  `client_address` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `client_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_username`, `client_name`, `client_phone`, `client_email`, `client_address`, `client_password`) VALUES
('amir', 'amir ramac', '09776775389', 'amir@gmail.com', 'pol.so.cot.', 'amir123');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_username` varchar(50) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_email` varchar(25) NOT NULL,
  `customer_address` varchar(50) NOT NULL,
  `customer_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_username`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_password`) VALUES
('amir', 'amir', '09776775389', 'amiramac10@gmail.com', 'esposado', 'amir123');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(20) NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `dl_number` varchar(50) NOT NULL,
  `driver_phone` varchar(15) NOT NULL,
  `driver_address` varchar(50) NOT NULL,
  `driver_gender` varchar(10) NOT NULL,
  `client_username` varchar(50) NOT NULL,
  `driver_availability` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `driver_name`, `dl_number`, `driver_phone`, `driver_address`, `driver_gender`, `client_username`, `driver_availability`) VALUES
(16, 'ricky', '123', '09886556897', 'pol.so.cot.', 'male', 'amir', 'yes'),
(17, 'ej', '123456', '09556225362', 'tampakan', 'male', 'amir', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `gowns`
--

CREATE TABLE `gowns` (
  `gown_id` int(20) NOT NULL,
  `gown_name` varchar(50) NOT NULL,
  `gown_nameplate` varchar(50) NOT NULL,
  `gown_img` varchar(50) DEFAULT 'NA',
  `ac_price` int(11) NOT NULL,
  `non_ac_price` int(11) NOT NULL,
  `ac_price_per_day` int(11) NOT NULL,
  `non_ac_price_per_day` int(11) NOT NULL,
  `gown_availability` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gowns`
--

INSERT INTO `gowns` (`gown_id`, `gown_name`, `gown_nameplate`, `gown_img`, `ac_price`, `non_ac_price`, `ac_price_per_day`, `non_ac_price_per_day`, `gown_availability`) VALUES
(39, 'wedddding', '1000', 'assets/img/gowns/wedding.png', 50, 100, 300, 150, 'yes'),
(41, 'ball', '2000', 'assets/img/gowns/ball gown.png', 150, 50, 300, 150, 'yes'),
(42, 'ball', '1000', 'assets/img/gowns/ball gown.png', 150, 50, 300, 150, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `rentedgowns`
--

CREATE TABLE `rentedgowns` (
  `id` int(100) NOT NULL,
  `customer_username` varchar(50) NOT NULL,
  `gown_id` int(20) NOT NULL,
  `driver_id` int(20) NOT NULL,
  `booking_date` date NOT NULL,
  `rent_start_date` date NOT NULL,
  `rent_end_date` date NOT NULL,
  `gown_return_date` date DEFAULT NULL,
  `fare` double NOT NULL,
  `charge_type` varchar(25) NOT NULL DEFAULT 'days',
  `distance` double DEFAULT NULL,
  `no_of_days` int(50) DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `return_status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rentedgowns`
--

INSERT INTO `rentedgowns` (`id`, `customer_username`, `gown_id`, `driver_id`, `booking_date`, `rent_start_date`, `rent_end_date`, `gown_return_date`, `fare`, `charge_type`, `distance`, `no_of_days`, `total_amount`, `return_status`) VALUES
(574681301, 'amir', 39, 16, '2024-05-14', '2024-05-16', '2024-05-22', '2024-05-14', 300, 'days', NULL, 6, 1800, 'R'),
(574681302, 'amir', 39, 17, '2024-05-14', '2024-05-15', '2024-05-22', '2024-05-14', 50, 'km', 12, 7, 600, 'R'),
(574681303, 'amir', 41, 16, '2024-05-14', '2024-05-15', '2024-05-15', '2024-05-14', 150, 'km', 15, 0, 2250, 'R'),
(574681305, 'amir', 39, 17, '2024-05-14', '2024-05-15', '2024-05-22', '2024-05-14', 50, 'km', 6, 7, 300, 'R');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientgowns`
--
ALTER TABLE `clientgowns`
  ADD PRIMARY KEY (`gown_id`),
  ADD KEY `client_username` (`client_username`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_username`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driver_id`),
  ADD UNIQUE KEY `dl_number` (`dl_number`),
  ADD KEY `client_username` (`client_username`);

--
-- Indexes for table `gowns`
--
ALTER TABLE `gowns`
  ADD PRIMARY KEY (`gown_id`);

--
-- Indexes for table `rentedgowns`
--
ALTER TABLE `rentedgowns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_username` (`customer_username`),
  ADD KEY `car_id` (`gown_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `driver_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `gowns`
--
ALTER TABLE `gowns`
  MODIFY `gown_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `rentedgowns`
--
ALTER TABLE `rentedgowns`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=574681306;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clientgowns`
--
ALTER TABLE `clientgowns`
  ADD CONSTRAINT `clientgowns_ibfk_1` FOREIGN KEY (`client_username`) REFERENCES `clients` (`client_username`),
  ADD CONSTRAINT `clientgowns_ibfk_2` FOREIGN KEY (`gown_id`) REFERENCES `gowns` (`gown_id`);

--
-- Constraints for table `driver`
--
ALTER TABLE `driver`
  ADD CONSTRAINT `driver_ibfk_1` FOREIGN KEY (`client_username`) REFERENCES `clients` (`client_username`);

--
-- Constraints for table `rentedgowns`
--
ALTER TABLE `rentedgowns`
  ADD CONSTRAINT `rentedgowns_ibfk_1` FOREIGN KEY (`customer_username`) REFERENCES `customers` (`customer_username`),
  ADD CONSTRAINT `rentedgowns_ibfk_2` FOREIGN KEY (`gown_id`) REFERENCES `gowns` (`gown_id`),
  ADD CONSTRAINT `rentedgowns_ibfk_3` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
